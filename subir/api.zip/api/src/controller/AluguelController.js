import {

    ListarSalas

} from '../repository/ClienteRepository.js';

import { Router } from 'express';

const endpoints = Router();

endpoints.get('/Salas', async (req, resp) => {
    let r = await ListarSalas();
    resp.send(r);
})


export default endpoints;