import 'dotenv/config';
import express from 'express';
import cors from 'cors';

import aluguelcontroller from './controller/AluguelController.js';

const servidor = express();
servidor.use(cors());
servidor.use(express.json());

servidor.use(aluguelcontroller);


servidor.listen(
  process.env.PORT,
  () => console.log(`API subiu na porta ${process.env.PORT}`));