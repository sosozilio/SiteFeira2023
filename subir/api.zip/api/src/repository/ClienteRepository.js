import connection from "./connection.js";

export async function ListarSalas() {
let comando = `

select  id_sala
	    ds_sobre
	    ds_andar
	    nr_pessoas
from    tb_salas


`
let [dados] = await connection.query(comando,[]);
return (dados);

};
