import mysql2 from 'mysql2/promise';

const connection = await mysql2.createConnection({
  host: "localhost",
  user: "developerOne",
  password: "Ricadito991",
  database: "salasdb"
})

console.log('DB conectado!');

export default connection;